# TaskPilot AI

Describe a task, get matched with suitable AI tools. Plain HTML, CSS and JavaScript: no backend, no API keys, no login.

**Honest note:** recommendations come from keyword-matching rules in `script.js` against the catalogue in `tools.js`. There is no live AI model. "Free option" reflects free plans known when the catalogue was written; check each site because plans change.

## Publish on GitHub Pages
1. Sign in at github.com. Click **+** (top right) > **New repository**.
2. Name it (e.g. `taskpilot-ai`), choose **Public**, click **Create repository**.
3. Click **uploading an existing file**. Drag in `index.html`, `styles.css`, `script.js`, `tools.js`, `README.md` and the `assets` folder (keep `assets/favicon.svg` inside `assets`). Click **Commit changes**.
4. Go to **Settings > Pages**. Under **Build and deployment**, set Source to **Deploy from a branch**, Branch **main**, folder **/ (root)**, then **Save**.
5. Wait 1-2 minutes. Your site is at `https://USERNAME.github.io/REPOSITORY-NAME/`.

All paths are relative and navigation uses `#` links, so it works under a repository sub-path.

## Edit the catalogue
Open `tools.js`, copy a tool entry, and change `name`, `url`, `desc`, `cats`, `users`, `free`, `strengths`, `limits` and `kw` (keywords and synonyms users might type). `w` is a small weight that favours specialist tools. Commit the change and the site updates.

## Test locally
Double-click `index.html`. No server needed.

## Previewing
- **On your computer:** double-click `index.html` (keep all files in the same folder structure).
- **In a previewer that shows only one file:** open `standalone.html`, a single-file copy with the CSS and JavaScript inlined. If you edit `styles.css`, `script.js` or `tools.js`, `standalone.html` will not update; GitHub Pages only needs `index.html`.
