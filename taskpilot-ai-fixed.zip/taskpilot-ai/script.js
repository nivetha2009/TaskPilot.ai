(function(){
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=t=>String(t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const norm=t=>t.toLowerCase().replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim();
const STOP=new Set("i want to a an the my me for of and or with from in on is it that this can you please need make get some how do".split(" "));

// ---- Navigation (single-page views, hash-based so GitHub Pages subpaths work)
const VIEWS=["home","explore","how","about"];
function show(v){ if(!VIEWS.includes(v)) v="home";
  VIEWS.forEach(x=>{$("#view-"+x).hidden=x!==v;});
  $$("[data-nav]").forEach(a=>a.classList.toggle("active",a.dataset.nav===v));
  $("#nav").classList.remove("open"); $("#menuBtn").setAttribute("aria-expanded","false");
  window.scrollTo(0,0); }
window.addEventListener("hashchange",()=>show(location.hash.slice(1)));
$("#menuBtn").onclick=()=>{const o=$("#nav").classList.toggle("open");$("#menuBtn").setAttribute("aria-expanded",o);};

// ---- Recommendation engine: keyword/phrase scoring (no live AI)
function score(task,tool,cat){
  const text=" "+norm(task)+" ", words=text.trim().split(" ").filter(w=>!STOP.has(w));
  let s=0, hits=[];
  tool.kw.forEach(k=>{ const nk=norm(k);
    if(nk.includes(" ")){ if(text.includes(" "+nk+" ")){s+=3;hits.push(k);} }
    else if(words.includes(nk) || words.includes(nk+"s")){s+=2;hits.push(k);} });
  tool.cats.forEach(c=>{ const cc=CATEGORIES.find(x=>x.id===c);
    if(cc&&words.some(w=>w.length>3&&norm(cc.name).includes(w))) s+=0.5; });
  if(s>0) s*=tool.w;
  return {tool,s,hits:[...new Set(hits)]};
}
function recommend(task){
  const r=TOOLS.map(t=>score(task,t)).filter(x=>x.s>0).sort((a,b)=>b.s-a.s);
  return r.slice(0,5);
}
function reason(r){
  const h=r.hits.slice(0,3).map(x=>`"${x}"`).join(", ");
  return `Your request mentions ${h}, which matches what ${r.tool.name} is built for.`;
}
function card(t,opts={}){
  return `<article class="card ${opts.best?"best":""}">
   ${opts.best?'<span class="badge">Best match</span>':""}
   <div class="card-top"><h3>${esc(t.name)}</h3>${t.free?'<span class="pill free">Free option</span>':'<span class="pill">Paid</span>'}</div>
   <p>${esc(t.desc)}</p>
   ${opts.reason?`<p class="why"><strong>Why this tool:</strong> ${esc(opts.reason)}</p>`:""}
   <div class="cols"><div><h4>Strengths</h4><ul>${t.strengths.map(s=>`<li>${esc(s)}</li>`).join("")}</ul></div>
   <div><h4>Limitations</h4><ul>${t.limits.map(s=>`<li>${esc(s)}</li>`).join("")}</ul></div></div>
   <div class="tags">${t.cats.map(c=>`<span>${esc(CATEGORIES.find(x=>x.id===c).name)}</span>`).join("")}</div>
   <a class="btn small" href="${t.url}" target="_blank" rel="noopener noreferrer">Open ${esc(t.name)}</a></article>`;
}
function find(task){
  const out=$("#results"); task=task.trim();
  if(!task){ out.innerHTML='<div class="notice">Describe a task first, for example “make a presentation for my class”.</div>'; return; }
  const rec=recommend(task);
  if(!rec.length){ out.innerHTML=`<div class="notice"><strong>No close match found.</strong> Try different words (e.g. “presentation”, “resume”, “video”, “code”), or <a href="#explore">browse all tools</a>. ChatGPT, Claude and Gemini handle many general tasks.</div>`; return; }
  const [best,...alts]=rec;
  out.innerHTML=`<h2>Best match for your task</h2>${card(best.tool,{best:true,reason:reason(best)})}
   ${alts.length?`<h2>Alternatives worth trying</h2><div class="grid">${alts.map(a=>card(a.tool,{reason:reason(a)})).join("")}</div>`:""}
   <p class="fine">Recommendations come from keyword-matching rules, not a live AI model. Always check each tool's site for current pricing and features.</p>`;
  out.scrollIntoView({behavior:"smooth",block:"start"});
}
$("#taskForm").addEventListener("submit",e=>{e.preventDefault();find($("#taskInput").value);});
$$(".example").forEach(b=>b.onclick=()=>{$("#taskInput").value=b.dataset.q;find(b.dataset.q);});

// ---- Categories on home
$("#catGrid").innerHTML=CATEGORIES.map(c=>`<button class="cat" data-cat="${c.id}"><span>${c.icon}</span>${esc(c.name)}</button>`).join("");
$$(".cat").forEach(b=>b.onclick=()=>{ $("#fCat").value=b.dataset.cat; renderDir(); location.hash="explore"; });

// ---- Directory with search + filters
$("#fCat").innerHTML='<option value="">All categories</option>'+CATEGORIES.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
function renderDir(){
  const q=norm($("#dirSearch").value), cat=$("#fCat").value, user=$("#fUser").value, free=$("#fFree").checked;
  const list=TOOLS.filter(t=>(!cat||t.cats.includes(cat))&&(!user||t.users.includes(user))&&(!free||t.free)
    &&(!q||norm([t.name,t.desc,t.kw.join(" ")].join(" ")).includes(q))).sort((a,b)=>a.name.localeCompare(b.name));
  $("#dirCount").textContent=`${list.length} of ${TOOLS.length} tools`;
  $("#dirGrid").innerHTML=list.length?list.map(t=>card(t)).join(""):'<div class="notice">No tools match. Clear a filter or change your search.</div>';
}
["dirSearch","fCat","fUser","fFree"].forEach(id=>$("#"+id).addEventListener("input",renderDir));
$("#fReset").onclick=()=>{$("#dirSearch").value="";$("#fCat").value="";$("#fUser").value="";$("#fFree").checked=false;renderDir();};
renderDir(); show(location.hash.slice(1));
})();
